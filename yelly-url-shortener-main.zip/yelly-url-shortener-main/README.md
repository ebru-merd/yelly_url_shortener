# Yelly - Url Shortener

### NodeJS, EJS, ExpressJS, Mongoose, MongoDB, PassportJS, Express-Session


![Image1](screenshots/sc1.png)
![Image1](screenshots/sc2.png)
![Image1](screenshots/sc3.png)


